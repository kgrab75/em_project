<section class="col-sm-8">

    <h1>Contact</h1>

    <div class="alert alert-success">
        <p>Votre message a bien été envoyé.</p>
        <p>Nous vous recontacterons dans les plus brefs délais</p>
    </div>

</section>