<div class="col-sm-8 content">

    <h1>Le projet</h1>

    <img class="leftImg" src="<?= base_url(); ?>assets/images/image1.jpg" alt="Illustration 1"/>

    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliena dixit in physicis nec ea ipsa, quae tibi probarentur; <a href='#' target='_blank'>Quo modo?</a> Vitiosum est enim in dividendo partem in genere numerare. Luxuriam non reprehendit, modo sit vacua infinita cupiditate et timore. <i>Tu quidem reddes;</i> Esse enim quam vellet iniquus iustus poterat inpune. Quae si potest singula consolando levare, universa quo modo sustinebit? Tria genera bonorum; </p>

    <ol>
        <li>Ergo ita: non posse honeste vivi, nisi honeste vivatur?</li>
        <li>Eodem modo is enim tibi nemo dabit, quod, expetendum sit, id esse laudabile.</li>
        <li>Scripta sane et multa et polita, sed nescio quo pacto auctoritatem oratio non habet.</li>
        <li>Haeret in salebra.</li>
    </ol>


    <p>Ex quo, id quod omnes expetunt, beate vivendi ratio inveniri et comparari potest. Vitiosum est enim in dividendo partem in genere numerare. Ubi ut eam caperet aut quando? Vadem te ad mortem tyranno dabis pro amico, ut Pythagoreus ille Siculo fecit tyranno? Nihil ad rem! Ne sit sane; Qui est in parvis malis. <b>Immo videri fortasse.</b> <a href='#' target='_blank'>Murenam te accusante defenderem.</a> Bonum negas esse divitias, praeposìtum esse dicis? </p>

    <blockquote cite='http://loripsum.net'>
        Si quidem, inquit, tollerem, sed relinquo.
    </blockquote>

    <p>Nihil acciderat ei, quod nollet, nisi quod anulum, quo delectabatur, in mari abiecerat. Laboro autem non sine causa; Tamen a proposito, inquam, aberramus. Qui non moveatur et offensione turpitudinis et comprobatione honestatis? Quid autem habent admirationis, cum prope accesseris? Hoc non est positum in nostra actione.  Hic nihil fuit, quod quaereremus. </p>


    <ul>
        <li>Ergo, inquit, tibi Q.</li>
        <li>Polemoni et iam ante Aristoteli ea prima visa sunt, quae paulo ante dixi.</li>
        <li>Equidem, sed audistine modo de Carneade?</li>
        <li>Neque solum ea communia, verum etiam paria esse dixerunt.</li>
        <li>Sed emolumenta communia esse dicuntur, recte autem facta et peccata non habentur communia.</li>
        <li>Multa sunt dicta ab antiquis de contemnendis ac despiciendis rebus humanis;</li>
    </ul>

    <p>Si quicquam extra virtutem habeatur in bonis. Cave putes quicquam esse verius. Hoc sic expositum dissimile est superiori. Habes, inquam, Cato, formam eorum, de quibus loquor, philosophorum. </p>

    <p>Esse enim, nisi eris, non potes. <i>Poterat autem inpune;</i> <a href='#' target='_blank'>Quod cum dixissent, ille contra.</a> Mihi quidem Antiochum, quem audis, satis belle videris attendere. <i>Ad eos igitur converte te, quaeso.</i> </p>


    <blockquote cite='http://loripsum.net'>
        Si quidem, inquit, tollerem, sed relinquo.
    </blockquote>



</div>
