<div class="col-sm-8">

    <h1>Mentions légales</h1>

    <h4>Go Mobility</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Si longus, levis dictata sunt. Hic nihil fuit, quod quaereremus. Primum quid tu dicis breve? <a href='http://loripsum.net/' target='_blank'>Immo videri fortasse.</a> </p>

    <ul>
        <li>Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest.</li>
        <li>Quasi ego id curem, quid ille aiat aut neget.</li>
        <li>Hoc est non dividere, sed frangere.</li>
    </ul>


    <p>A mene tu? <b>Illi enim inter se dissentiunt.</b> <i>Suo genere perveniant ad extremum;</i> <a href='http://loripsum.net/' target='_blank'>Duo Reges: constructio interrete.</a> Et quidem, inquit, vehementer errat; Contineo me ab exemplis. </p>

    <p>At iste non dolendi status non vocatur voluptas. <a href='http://loripsum.net/' target='_blank'>Sed nimis multa.</a> </p>



    <h4>Design</h4>
    <ul>
        <li>Rémi BOUCHET : remi.bouchet0901@gmail.com</li>
        <li>Gabriel LIST : list.gabriel@gmail.com</li>
    </ul>

    <h4>Développement </h4>
    <ul>
        <li>Kévin GRABINER : kgrabiner75@gmail.com</li>
        <li>Virginie JOSEPH-LOCKEL : vjlockel@gmail.com</li>
    </ul>


</div>