<section class="col-sm-8">

    <h1>Participation</h1>

    <div class="alert alert-success">
        <H2>Votre expérience a bien été enregistrée.</h2>
        <h4>Cette dernière sera publiée sous 24h, dès validation par l'un de nos modérateurs.</h4>
    </div>

</section>