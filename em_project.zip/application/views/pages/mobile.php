<section class="col-sm-8">

    <h1>Application mobile</h1>

    <p>Si quicquam extra virtutem habeatur in bonis. Cave putes quicquam esse verius. Hoc sic expositum dissimile est superiori. Habes, inquam, Cato, formam eorum, de quibus loquor, philosophorum. </p>

    <div class="clear"> </div>

    <h3 class="text-center">Télécharger dès maintenant l'application Go Mobility</h3>

    <div class="col-sm-4">
        <a href="#" role="button" class="btn btn-default btn-lg btn-block"><i class="fa fa-apple"  style="font-size: 3em"></i><br/>Apple</a>
    </div>
    <div class="col-sm-4">
        <a href="#" role="button" class="btn btn-success btn-lg btn-block"><i class="fa fa-android"  style="font-size: 3em"></i><br/>Android</a>
    </div>
    <div class="col-sm-4">
        <a href="#" role="button" class="btn btn-info btn-lg btn-block"><i class="fa fa-windows"  style="font-size: 3em"></i><br/>Windows</a>
    </div>

    <div class="col-sm-12">
        <p class="text-center">
            <img src="<?= base_url(); ?>assets/images/appli-mobile.jpg" alt="Application mobile go mobility" width="100%"/>
        </p>

    </div>

</section>