<section class="col-sm-8">

    <h1>Jeu concours</h1>

    <h3>Gagnez votre vélo électrique grâce à Go Mobility !</h3>

    <div class="col-sm-12">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit sane ista voluptas. <a href='#'>Quid me istud rogas?</a> Nihilo beatiorem esse Metellum quam Regulum. Itaque his sapiens semper vacabit. Num quid tale Democritus? </p>

        <blockquote cite='http://loripsum.net'>
            Quae diligentissime contra Aristonem dicuntur a Chryippo.
        </blockquote>


        <p>Quod totum contra est. Duo Reges: constructio interrete. Ostendit pedes et pectus. Quis istud possit, inquit, negare? <a href='http://loripsum.net/' target='_blank'>Praeteritis, inquit, gaudeo.</a> <a href='http://loripsum.net/' target='_blank'>At iam decimum annum in spelunca iacet.</a> </p>

        <ul>
            <li>Quid affers, cur Thorius, cur Caius Postumius, cur omnium horum magister, Orata, non iucundissime vixerit?</li>
            <li>Cur igitur, inquam, res tam dissimiles eodem nomine appellas?</li>
        </ul>

        <div class="text-center">
            <img src="<?= base_url(); ?>assets/images/velo.jpg" alt="Vélo électrique"/>
        </div>

    </div>

    <div class="col-sm-12">
        <a role="button" class="btn btn-primary btn-block btn-lg" href="<?php echo base_url().'participation';?>">Participer !</a>
    </div>


</section>