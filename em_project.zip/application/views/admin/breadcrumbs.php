<ol class="breadcrumb breadcrumb-admin">

    <li class="active"> <?php echo $title ?></li>

</ol>