<aside class="col-sm-4">
    <? $this->load->view($sidebar_content['info']); ?>
    <? $this->load->view($sidebar_content['actu']); ?>
    <? $this->load->view($sidebar_content['community']); ?>
</aside>
