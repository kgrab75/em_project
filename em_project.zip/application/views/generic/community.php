<section class="col-sm-12">

    <h2 class="bg-primary panel-heading no-margin-bottom">Nous retrouver</h2>

    <!-- FACEBOOK -->
    <div class="fb-like-box col-sm-12 bg-secondary sideContent" data-href="https://www.facebook.com/GoMobilityArdeche" data-colorscheme="light" data-show-faces="false" data-header="true" data-stream="false" data-show-border="true"></div>

    <!-- TWITTER -->
    <div class="col-sm-12 bg-secondary sideContent">
        <a class="twitter-timeline " data-dnt="true" href="https://twitter.com/GoMobilityArd"  height="250" data-widget-id="496586686801788928">Tweets de @GoMobilityArd</a>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
    </div>


</section>