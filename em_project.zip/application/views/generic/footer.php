</div> <!-- / .container-->

        <!-- FOOTER -->
        <footer class="footer">
            <div class="container">

                <div class="col-sm-4">
                    <p class="text-left"><a class="padLink" href="<?= base_url(); ?>ml">Mentions légales</a> <a class="padLink" href="<?= base_url(); ?>contact">Contact</a></p>
                </div>

                <div class="col-sm-8">
                    <p class="text-right">
                        Partenaires : <a href="http://www.pays-ardeche-meridionale.net/" target="_blank">Le Pays de l'Ardèche méridional</a>,
                        <a href="https://www.ardeche.fr/" target="_blank">Le conseil général de l'Ardèche</a>
                    </p>
                </div>

            </div>


        </footer>


        <!-- FIN FOOTER -->






<!-- SCRIPT -->
<script src=""></script>


</body>
</html>