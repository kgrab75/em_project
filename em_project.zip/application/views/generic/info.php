<section class="col-sm-12">
    <h2 class="bg-primary panel-heading no-margin-bottom">Informations</h2>
    <ul class="list-unstyled col-sm-12 bg-secondary info sideContent">
        <li>
            <a href="<?= base_url(); ?>experiences/all/">
                <span class="badge"><?php echo $experienceCount; ?></span>expériences

            </a>
        </li>
        <li>
            <a href="<?= base_url(); ?>ecoactors">
                <i class="fa fa-trophy "></i>Meilleurs éco-acteurs
            </a>
        </li>
        <li>
            <a href="<?= base_url(); ?>mobile">
                <i class="fa fa-mobile-phone"></i>Application mobile
            </a>
        </li>
    </ul>
</section>