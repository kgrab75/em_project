<?php

class Accueil extends CI_Controller {

    function blog()
    {

    }
}